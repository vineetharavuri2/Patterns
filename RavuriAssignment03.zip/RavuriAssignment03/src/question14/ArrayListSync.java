package question14;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public class ArrayListSync {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<String> l1 = new ArrayList<String>();
		l1.add("Vineetha");
		l1.add("Manoj");
		l1.add("Anila");
		l1.add("Sweety");
		
		l1 = Collections.synchronizedList(l1);
		synchronized(l1) {
			Iterator<String> itr = l1.listIterator();
			while(itr.hasNext()) {
				System.out.println(itr.next());
			}
		}
	}


}


