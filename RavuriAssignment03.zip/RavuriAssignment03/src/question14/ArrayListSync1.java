package question14;

import java.util.ArrayList;
import java.util.Iterator;

public class ArrayListSync1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<String> names = new ArrayList<String>();
		names.add("Vineetha");
		names.add("Manoj");
		names.add("Anila");
    System.out.println("Elements of synchronized ArrayList :");

    Iterator<String> itr = names.iterator();
    while (itr.hasNext())
        System.out.println(itr.next());
	}


	}


