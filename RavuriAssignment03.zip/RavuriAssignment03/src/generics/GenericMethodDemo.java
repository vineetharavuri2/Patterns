package generics;

public class GenericMethodDemo {

		public static <Practice> void printArray(Practice[] input) {
			
			for(Practice print: input) {
				System.out.print(print + " ");
			}
			System.out.println();
		}
		
		public static void main(String[] args) {
			String[] names = {"Vinee", "Manu"};
			System.out.println("Generic method contain: ");
			printArray(names);
		}


}


