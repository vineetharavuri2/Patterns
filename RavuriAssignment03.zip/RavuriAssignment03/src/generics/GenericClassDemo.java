package generics;

public class GenericClassDemo<T> {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		GenericClassDemo g1 = new GenericClassDemo();
		g1.setName("Vineetha");
		System.out.println(g1);
	}

	private T name;

	public T getName() {
		return name;
	}

	public void setName(T name) {
		this.name = name;
	}
	
	@Override
	public String toString() {
		return "name= " + name;
	}
}


