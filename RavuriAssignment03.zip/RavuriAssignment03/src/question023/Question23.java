package question023;

public class Question23 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String name = "Vineetha";
		name.concat("Ravuri");
		System.out.println("name : " +name);
		Thread tem = new Thread(new Runnable() {
			public void run() {
				name.concat("tem");
				System.out.println("Thread: " +name);
				
			}

		});
		Thread t = new Thread(new Runnable() {
			public void run() {
				name.concat("t");
				System.out.println("Thread1 : " +name);
				
			}
			
		});
		tem.start();
		t.start();



	}

	}


