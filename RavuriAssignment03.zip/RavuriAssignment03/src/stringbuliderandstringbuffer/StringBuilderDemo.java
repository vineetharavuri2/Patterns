package stringbuliderandstringbuffer;

public class StringBuilderDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StringBuilder st = new StringBuilder("Hello ");
		st.append("Hi ");
		System.out.println(st);
		st.append("StringBuilder");
		System.out.println(st);


	}

}
