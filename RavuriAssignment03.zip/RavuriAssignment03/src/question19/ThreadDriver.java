package question19;

public class ThreadDriver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.out.println("Starting Main Thread...");
        ThreadExample th = new ThreadExample();

         Thread t = new Thread(th);
         t.start();
         System.out.println("End of Main Thread...");
       }
}

	


