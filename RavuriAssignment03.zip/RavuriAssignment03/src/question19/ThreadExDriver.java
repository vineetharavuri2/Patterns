package question19;

public class ThreadExDriver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ThreadEx t = new ThreadEx();
		t.start();



	}

}
