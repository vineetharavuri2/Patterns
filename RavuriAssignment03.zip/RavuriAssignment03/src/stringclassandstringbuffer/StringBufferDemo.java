package stringclassandstringbuffer;

public class StringBufferDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StringBuffer stb= new StringBuffer("Demo Class of StringBuffer");
        System.out.println(stb.toString());
        stb.reverse();
       System.out.println(stb.toString());
      }


	}


