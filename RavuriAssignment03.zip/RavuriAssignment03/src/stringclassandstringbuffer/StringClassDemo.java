package stringclassandstringbuffer;

public class StringClassDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String st = "Vineetha";
	      String name = st.toUpperCase();
	      System.out.println(name);
	      String add = st.concat(" Ravuri");
	      System.out.println(add);
	   }


	}


