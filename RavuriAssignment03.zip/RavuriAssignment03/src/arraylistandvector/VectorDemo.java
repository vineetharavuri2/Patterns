package arraylistandvector;

import java.util.Enumeration;
import java.util.Vector;

public class VectorDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Vector v = new Vector(); 	 
		//Adding elements to vector
		v.addElement("Vineetha"); 
		v.addElement("Ravuri");
		// Traversing vector elements
		System.out.println("Name:"); 
		Enumeration em = v.elements(); 
		while (em.hasMoreElements()) { 
			System.out.println(em.nextElement());
		}
	}


	}


