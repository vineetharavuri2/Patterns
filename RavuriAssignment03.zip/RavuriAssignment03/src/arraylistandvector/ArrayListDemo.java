package arraylistandvector;

import java.util.ArrayList;
import java.util.Iterator;

public class ArrayListDemo {

       public static void main(String[] args) {
		// TODO Auto-generated method stub
    	   ArrayList al = new ArrayList();
    	   al.add("Vineetha");
		   al.add("Ravuri"); 
 
		// Traversing ArrayList elements
		System.out.println("al:"+al); 
		Iterator it = al.iterator(); 
		while (it.hasNext()) { 
			System.out.println(it.next()); 
	}

	}
}

