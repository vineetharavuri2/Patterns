package question2;

public class Question2 {

}
