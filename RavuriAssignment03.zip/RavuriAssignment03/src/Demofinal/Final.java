package Demofinal;

public class Final {

	public final int age = 25;  
    public void display()
   {  
    System.out.println("Age :" +age);
    }  
      

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Final obj = new Final();    
	    obj.display();  
	    }  
 }


