package question25;

public class LambdaDriver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int side=5;  
        
		//with lambda  
        LambdaExpresionDemo l1=()->{  
            System.out.println("Display "+side);  
        };  
        l1.display();  
    }   





	}


