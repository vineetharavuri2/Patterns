package question25;

public interface LambdaExpresionDemo {
	public void display();

}
