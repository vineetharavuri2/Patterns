package question25;

public class JavaStream {
	String name;  
    float price;  
    public JavaStream(String name, float price) {   
        this.name = name;  
        this.price = price;  
    }  
}  




