package question25;

public interface FunctionalInterfaceDemo {

	public void say(String msg);
}
