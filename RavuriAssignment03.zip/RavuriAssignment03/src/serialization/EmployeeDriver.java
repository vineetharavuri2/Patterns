package serialization;

import java.io.FileOutputStream;
import java.io.ObjectOutputStream;

public class EmployeeDriver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try{
            Employee em1 =new Employee(25,"Vinee",40000);
            Employee em2 =new Employee(24,"Manu",70000);
            Employee em3 =new Employee(26,"Ani",60000);
            FileOutputStream fout=new FileOutputStream("output.txt");
            ObjectOutputStream out=new ObjectOutputStream(fout);
            out.writeObject(em1);
            out.writeObject(em2);
            out.flush();
            out.close();
            System.out.println("Successfully");
     }
     catch(Exception e){
            System.out.println(e);
            }
	}



	}


