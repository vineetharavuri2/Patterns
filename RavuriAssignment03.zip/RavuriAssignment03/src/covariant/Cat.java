package covariant;

public class Cat extends Animal {
	public Cat getDetails(){ 
	    System.out.println("Hello, this is the Cat class"); 
	     return this; 
	  } 
	  
	  public void sound() {
		  System.out.println("Cat will sound meow");
	  }
}



