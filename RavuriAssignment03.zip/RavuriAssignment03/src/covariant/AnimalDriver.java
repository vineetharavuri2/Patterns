package covariant;

public class AnimalDriver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new Cat().getDetails().sound();

	}

}
