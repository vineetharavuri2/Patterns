package covariant;

public class Animal {
	public Animal getDetails(){ 
		   System.out.println("Hello, this is a superclass"); 
		    return this; 
		  } 


}
