package constructor;

public class FinalConstructorDemo {
       public final String name;
		public final int age;
		 	
		public final FinalConstructorDemo() {
			this.name = "";
			this.age = 25;
		}
		
		public void display() {
		    System.out.println("Name of the Student: "+this.name );
		    System.out.println("Age of the Student: "+this.age );
		}
		public static void main(String[] args) {
			// TODO Auto-generated method stub
			new FinalConstructorDemo().display();
		}
		

 
	}


