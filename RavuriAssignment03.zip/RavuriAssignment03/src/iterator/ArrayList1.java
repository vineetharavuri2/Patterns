package iterator;

import java.util.ArrayList;
import java.util.Iterator;

public class ArrayList1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<String> al = new ArrayList<String>();
		al.add("Vineetha");
		al.add("Manoj");
		al.add("Anila");
    System.out.println(" synchronized ArrayList Elements :");

    Iterator<String> itr = al.iterator();
    while (itr.hasNext())
        System.out.println(itr.next());
	}


	}


