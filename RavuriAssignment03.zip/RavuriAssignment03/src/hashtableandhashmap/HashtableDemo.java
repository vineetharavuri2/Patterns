package hashtableandhashmap;

import java.util.Hashtable;
import java.util.Map;

public class HashtableDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Map<String,String> m = new Hashtable<String,String>();
		m.put("Vinee", "Vineetha");
		m.put("Manu", "Manoj");
		m.put("Ani", "Anila");
		m.put("Sweety", null);
		
		System.out.print("Elements in Hashtable are:\n " + m.entrySet());
		System.out.println(m.get("Vinee"));
		//System.out.println(names.get("SWeety"));//Exception
	}


	}


