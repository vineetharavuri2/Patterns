package hashtableandhashmap;

import java.util.HashMap;
import java.util.Map;

public class HashmapDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Map<String,String> m = new HashMap<String,String>();
		m.put("Vinee", "Vineetha");
		m.put("Manu", "Manoj");
		m.put("Ani", "Anila");
		m.put("Sweety", null);
		m.put(null, null);
		m.put(null, "Annu");
		
		System.out.print("Elements in Hashtable are:\n " + m.entrySet());
		System.out.println(m.get("Vinee"));
		System.out.println(m.get("Annu"));
	}


	}


