package immutable;

public class ImmutableDriver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Immutable obj1 = new Immutable("Vineetha", 24);

	    System.out.println("Name: " + obj1.getName());
	    System.out.println("Date: " + obj1.getAge());


	}

}
