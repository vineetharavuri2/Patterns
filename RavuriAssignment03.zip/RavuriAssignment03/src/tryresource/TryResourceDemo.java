package tryresource;

import java.io.File;
import java.util.Scanner;

public class TryResourceDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try (Scanner scan = new Scanner(new File("sample.txt")); ) {
		      while (scan.hasNext()) {
		        System.out.println(scan.nextLine());
		      }
		    } catch (Exception e){
		       System.out.println("FilenotFound Exception is thrown" + e);
		       }
	}



	}


